al = []
sum = 0

for i in range(5):
    i = int(input("정수 입력: "))
    al.append(i)

for i in al:
    sum +=i

avg = sum/len(al)
print("평균:",avg)
