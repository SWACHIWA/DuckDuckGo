from tkinter import *
def aa():
    print("ㅎㅇㅎㅇㅎㅇ")
def bb():
    exit()
window = Tk()
a = Label(window, text="간단한 GUI 프로그램!")
a.pack()
b = Button(window, text="환영합니다.", command=aa)
b.pack()
b1 = Button(window, text="종료", command=bb)
b1.pack()
window.mainloop()


