from tkinter import *


def go():
    l4["text"] = str(float(b.get()) * 2.54) + "센티미터"


window = Tk()

l1 = Label(window, text="인치를 센티미터로 변환하는 프로그램:")
l1.grid(row=0, columnspan=2)
l2 = Label(window, text="인치를 입력하시오:")
l2.grid(row=1, column=0)
b = Entry(window)
b.grid(row=1, column=1)
l3 = Label(window, text="변환 결과:")
l3.grid(row=2, column=0)
l4 = Label(window, text="0 센티미터")
l4.grid(row=2, column=1)
c1 = Button(window, text="변환!", command=go)
c1.grid(row=3, column=1)

window.mainloop()
