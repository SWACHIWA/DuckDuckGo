from tkinter import *

def p():
    global a
    a = a + int(b.get())
    a2["text"] = str(a)
def m():
    global a
    a = a - int(b.get())
    a2["text"] = str(a)
def r():
    global a
    a = 100
    a2["text"] = str(a)
    
window = Tk()

a = 100
a1 = Label(window, text="현재 합계:")
a2 = Label(window, text=a)
a1.grid(row=0,column=0)
a2.grid(row=0,column=1)

b=Entry(window)
b.grid(row=1,column=0, columnspan=2)
b1 = Button(window, text="더하기(+)", command=p)
b1.grid(row=2,column=0)
b2 = Button(window, text="빼기(-)", command=m)
b2.grid(row=2,column=1)
b3 = Button(window, text="초기화", command=r)
b3.grid(row=2,column=2)

window.mainloop()
