import random
count = [0, 0, 0, 0, 0, 0]

for i in range(1000):
    value = random.randint(0, 5)
    count[value] = count[value] + 1

for i in range(6):
    print("주사위가",i+1,"인 경우는",count[i],"번")
