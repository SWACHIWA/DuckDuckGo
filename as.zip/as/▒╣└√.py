from tkinter import *


def quits():
    exit()


window = Tk()

l1 = Label(window, text="이름")
l1.grid(row=0, column=0)
b1 = Entry(window)
b1.grid(row=0, column=1)

l2 = Label(window, text="직업")
l2.grid(row=1, column=0)
b2 = Entry(window)
b2.grid(row=1, column=1)

l3 = Label(window, text="국적")
l3.grid(row=2, column=0)
b3 = Entry(window)
b3.grid(row=2, column=1)

c1 = Button(window, text="Show")
c1.grid(row=3, column=0)
c2 = Button(window, text="Quit", command=quits)
c2.grid(row=3, column=1)

window.mainloop()
