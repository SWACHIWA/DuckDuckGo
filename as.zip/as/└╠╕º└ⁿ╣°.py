c = {}

while True:
    name = input("(입력)이름을 입력하세요:")
    if not name:
        break;
    tel = input("(입력)전화번호를 입력하세요:")
    c[name] = tel

while True:
    name = input("(검색)이름을 입력하세요:")
    if not name:
        break;
    if name in c:
        print(name,"의 전화번호는",c[name],"입니다.")
