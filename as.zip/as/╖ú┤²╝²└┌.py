from tkinter import *
import random


def inp():
    global a
    if a == int(b.get()):
        l1["text"] = "정답입니다~"
    elif a > int(b.get()):
        l1["text"] = "너무 낮아요!!"
    elif a < int(b.get()):
        l1["text"] = "너무 높아요!!"


def res():
    global a
    a = random.randint(0, 500)
    l1["text"] = "숫자가 정해졌습니다 맞춰보세요 ㅋ"


window = Tk()

a = random.randint(0, 500)

l1 = Label(window, text="숫자가 정해졌습니다 맞춰보세요 ㅋ")
l1.grid(row=0, columnspan=2)

b = Entry(window)
b.grid(row=1, columnspan=2)

c1 = Button(window, text="숫자를 입력", command=inp)
c1.grid(row=2, column=0)
c2 = Button(window, text="게임을 다시 실행", command=res)
c2.grid(row=2, column=1)

window.mainloop()
