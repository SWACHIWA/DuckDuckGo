domains = {"kr":"대한민국","us":"미국","jp":"일본",
           "de":"독일","sk":"슬로바키아","hu":"헝가리",
           "no":"노르웨이"}

for k, v in domains.items():
    print(k,":",v)
